import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CanComponentDeActivate } from '../unsaved-data.guard';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements CanComponentDeActivate {

  status: boolean = false;
  constructor() { }
  canDeactivate2(): boolean | Observable<boolean> | Promise<boolean> {

    if (this.status == false) {
      if (window.confirm("you have some unsaved data....Do you want to close it ")) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }



  }

  ngOnInit(): void {
  }

  updateStatus() {
    // alert("update called");
    this.status = true;
  }
}

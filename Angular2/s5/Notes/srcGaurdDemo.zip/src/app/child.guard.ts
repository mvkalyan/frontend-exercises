import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ChildGuard implements CanActivateChild{
  constructor(private authservice:AuthService,private router:Router){}
  
  canActivateChild(
    childRoute: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if(state.url=='/order/update')
        return this.checkIsUserAdmin(state.url);
    return true;
  }

  checkIsUserAdmin(url:string){
    console.log(url); 
    if(this.authservice.isUserAdmin){
      this.authservice.redirectUrl=url;
      return this.authservice.isUserAdmin;
    }
    else{
      return this.router.navigateByUrl("/login");
    }

  }
  
}

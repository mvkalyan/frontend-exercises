import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanLoad, Route, Router, RouterStateSnapshot, UrlSegment, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate,CanLoad{

  constructor(private authservice:AuthService,private router:Router){}
  
  canLoad(route: Route, segments: UrlSegment[]): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    return this.checkIsUserAdmin('admin')
  }
 
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.checkIsUserAdmin(state.url);
  }
  checkLogin(url:any){
    console.log(url);
    if(this.authservice.isLoggedIn==true){
      this.authservice.redirectUrl=url;
      return true;
    }else{
      //if user is not loggedin take user login page
      return this.router.navigateByUrl("/login");
    }
  }
  checkIsUserAdmin(url:string){
    console.log(url+ "url"); 
    if(this.authservice.isUserAdmin){
      this.authservice.redirectUrl=url;
      return this.authservice.isUserAdmin;
    }
    else{
      return this.router.navigateByUrl("/login");
    }

  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manageproduct',
  templateUrl: './manageproduct.component.html',
  styleUrls: ['./manageproduct.component.css']
})
export class ManageproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

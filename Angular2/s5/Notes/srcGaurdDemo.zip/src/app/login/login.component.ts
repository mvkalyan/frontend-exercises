import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router,private authservice:AuthService) {  }

  ngOnInit(): void {
  }

  // login for demo1

  // login(){
  //   //alert("Logged in called");
  //   this.authservice.login();
  //   this.router.navigateByUrl("/order");
  // }
  // // login for demo2
  
  // login(code:string){
  //   console.log("code:"+ code);
  //   this.authservice.login(code);
  //   this.router.navigateByUrl("/order");
  // }


  //login demo4

  login(code:string){
    this.authservice.login(code);
    alert(this.authservice.redirectUrl);
    this.router.navigate([this.authservice.redirectUrl]);
  }



}

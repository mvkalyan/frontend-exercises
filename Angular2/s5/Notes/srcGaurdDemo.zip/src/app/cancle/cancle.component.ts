import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancle',
  templateUrl: './cancle.component.html',
  styleUrls: ['./cancle.component.css']
})
export class CancleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

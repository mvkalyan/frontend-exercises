import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

    isLoggedIn:boolean=false;
    isUserAdmin:boolean=false;
    redirectUrl:string=""
  constructor() { }

  // //for demo 1
  // login(){
  //   this.isLoggedIn=true;
  //   console.log("User is logged in");
  // }



  //login method for demo2

  login(code:string){

    this.isLoggedIn=true;
    this.isUserAdmin=code.startsWith("admin");

  }
}

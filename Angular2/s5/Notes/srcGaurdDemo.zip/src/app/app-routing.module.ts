import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { CancleComponent } from './cancle/cancle.component';
import { ChildGuard } from './child.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderComponent } from './order/order.component';
import { UnsavedDataGuard } from './unsaved-data.guard';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"login",component:LoginComponent },
  {
    path:"admin",
    loadChildren:()=>import('./admin/admin.module').then(m=>m.AdminModule),
    canLoad:[AuthGuard]
  },
  {path:"order",component:OrderComponent, canActivate:[AuthGuard],
    canActivateChild:[ChildGuard],
    children:[
      {
        path:"details",component:OrderListComponent
      },
      {
        path:"cancle",component:CancleComponent
      },
      {
        path:"update",component:UpdateComponent,canDeactivate:[UnsavedDataGuard]

      }
    ]

  },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

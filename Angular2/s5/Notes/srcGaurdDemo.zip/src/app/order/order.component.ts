import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  constructor() { }

  orders:Array<any>=[
    {
      orderId:"101",
      productId:"p01",
      customerId:"c01"
    },
    {
      orderId:"102",
      productId:"p02",
      customerId:"c02"
    },
    {
      orderId:"103",
      productId:"p03",
      customerId:"c03"
    },
    {
      orderId:"104",
      productId:"p04",
      customerId:"c0"
    }
  ]

  ngOnInit(): void {
  }

}

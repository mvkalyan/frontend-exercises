import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UserService } from '../user.service';

import { WelcomeComponent } from './welcome.component';

describe('WelcomeComponent', () => {
  let component: WelcomeComponent;
  let fixture: ComponentFixture<WelcomeComponent>;

  beforeEach(async () => {
    // await TestBed.configureTestingModule({
    //   declarations: [ WelcomeComponent ]
    // })
    // .compileComponents();

    //fake service
    const userServiceStuf={
      isLoggedIn:true,
      user:{
        uname:"Test User"
      }
    }
    //if you want to inject fake service(i.e userServiceStuf)
      TestBed.configureTestingModule({
        declarations:[WelcomeComponent],
        providers:[{provide:UserService, useValue:userServiceStuf}]
      })
    

    fixture = TestBed.createComponent(WelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it("should check h1 tag",()=>{
    fixture=TestBed.createComponent(WelcomeComponent);
    const h1element=fixture.nativeElement

    expect(h1element.querySelector('h1')?.textContent).toContain("Welcome");

  });

  it("should inject a demo user service",()=>{
    fixture=TestBed.createComponent(WelcomeComponent)
    fixture.detectChanges()
    TestBed.inject(UserService);
    expect(fixture.nativeElement.querySelector('p').textContent).toContain("Welcome");
  })
  


});

import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Hero } from './hero';

@Injectable({
  providedIn: 'root'
})
export class ObsevaleDataService {

  constructor(private myClient:HttpClient) { }

  private url='api/hero';

  getHeros():Observable<Hero[]>{
    return this.myClient.get<Hero[]>(this.url);

  }
}

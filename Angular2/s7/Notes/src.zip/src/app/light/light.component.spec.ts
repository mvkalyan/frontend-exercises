import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LightComponent } from './light.component';

describe("Light Switch Component",()=>{

  it("should be toggle the light on & off",()=>{

    const myObj=new LightComponent();
    expect(myObj.isOn).toBe(false);

    myObj.clicked();
    expect(myObj.isOn).toBe(true);

    myObj.clicked();
    expect(myObj.isOn).toBe(false);

  });

  //check weather your message is getting correct
  it("should change message",()=>{

    const myObj1=new LightComponent();

    expect(myObj1.message).toEqual("Light is Off");
    myObj1.clicked()

    expect(myObj1.message).toEqual("Light is On");
    myObj1.clicked()

    expect(myObj1.message).toEqual("Light is Off");
    


  })




})
// describe('LightComponent', () => {
//   let component: LightComponent;
//   let fixture: ComponentFixture<LightComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ LightComponent ]
//     })
//     .compileComponents();

//     fixture = TestBed.createComponent(LightComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
//});

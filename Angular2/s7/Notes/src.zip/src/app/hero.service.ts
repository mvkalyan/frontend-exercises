import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  constructor() { }

  createData(){
    const herodata=[
      {id:1,name:"vivek"},
      {id:2,name:"Ankit"},
      {id:3,name:"gaurav"},
      {id:4,name:"tejas"},
    ]
    return herodata;
  }

}

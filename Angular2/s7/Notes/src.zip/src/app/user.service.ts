import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  user={
    uname:"jhon"
  }
  isLoggedIn:boolean=false;

  demo(){
    console.log("demo function");
    return "hello";
  }
}

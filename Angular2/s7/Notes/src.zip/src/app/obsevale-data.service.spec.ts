import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Hero } from './hero';

import { ObsevaleDataService } from './obsevale-data.service';

describe('ObsevaleDataService', () => {
  let service: ObsevaleDataService;
  let httpspy: { get: jasmine.Spy };

  //   let ob:ObsevaleDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule],
      providers:[ObsevaleDataService]
    });
    service = TestBed.inject(ObsevaleDataService);
    providers:[{provide:ObsevaleDataService,useValue:ObsevaleDataService}]
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  //when you have one service dependent on another service we need to create mock the dependant service(Httpclient) 
  
  const demoArray: Hero[] = [{ id: 1, name: "abc" }, { id: 2, name: "xyz" }];

  //create http mock
    httpspy = jasmine.createSpyObj("HttpClient", ['get']);
    const ob = new ObsevaleDataService(httpspy as any);
    ob.getHeros().subscribe(data => {
    expect(data).toEqual(demoArray);

  })

});

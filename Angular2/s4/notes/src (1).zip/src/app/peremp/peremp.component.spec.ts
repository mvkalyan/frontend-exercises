import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerempComponent } from './peremp.component';

describe('PerempComponent', () => {
  let component: PerempComponent;
  let fixture: ComponentFixture<PerempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PerempComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PerempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

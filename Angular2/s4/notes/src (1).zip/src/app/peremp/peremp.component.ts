import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-peremp',
  templateUrl: './peremp.component.html',
  styleUrls: ['./peremp.component.css']
})
export class PerempComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

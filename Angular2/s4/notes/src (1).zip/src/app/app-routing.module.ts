import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountsComponent } from './accounts/accounts.component';
import { DepartmentsComponent } from './departments/departments.component';
import { EmployeeComponent } from './employee/employee.component';
import { PerempComponent } from './peremp/peremp.component';
import { PurchaseComponent } from './purchase/purchase.component';
import { SalesComponent } from './sales/sales.component';
import { TempempComponent } from './tempemp/tempemp.component';

const routes: Routes = [
  {
    component:EmployeeComponent,path:"employee",
    children:[{component:PerempComponent,path:"permanent"},
    {component:TempempComponent,path:"temporary"}]
  },
  {component:DepartmentsComponent,path:"departments",
   children:[{path:"sales",component:SalesComponent},
   {path:"purchase",component:PurchaseComponent},
   {path:"account",component:AccountsComponent}]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

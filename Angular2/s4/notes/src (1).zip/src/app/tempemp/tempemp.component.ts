import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tempemp',
  templateUrl: './tempemp.component.html',
  styleUrls: ['./tempemp.component.css']
})
export class TempempComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

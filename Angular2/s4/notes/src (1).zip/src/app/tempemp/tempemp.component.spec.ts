import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TempempComponent } from './tempemp.component';

describe('TempempComponent', () => {
  let component: TempempComponent;
  let fixture: ComponentFixture<TempempComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TempempComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TempempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

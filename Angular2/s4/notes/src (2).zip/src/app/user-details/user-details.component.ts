import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { userInfo } from 'os';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
   usr:string="";
  constructor(private route:ActivatedRoute) {

   }

  ngOnInit(): void 
  {
    
  console.log(this.route.snapshot.params);          
                                                       
  this.usr=this.route.snapshot.params['id'];
}

}

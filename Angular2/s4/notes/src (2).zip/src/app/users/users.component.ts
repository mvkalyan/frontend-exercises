import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
    
  constructor(private router:Router,private act:ActivatedRoute) { }
  id:string="";
  ngOnInit(): void {
  }
  navtoUser(name:string)
  {
    this.router.navigateByUrl('/details/'+name);
   //this.router.navigate(['details',name]);
  }
}

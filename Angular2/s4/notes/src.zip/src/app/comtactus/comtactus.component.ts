import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comtactus',
  templateUrl: './comtactus.component.html',
  styleUrls: ['./comtactus.component.css']
})
export class ComtactusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

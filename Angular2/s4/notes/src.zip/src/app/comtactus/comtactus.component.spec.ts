import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComtactusComponent } from './comtactus.component';

describe('ComtactusComponent', () => {
  let component: ComtactusComponent;
  let fixture: ComponentFixture<ComtactusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComtactusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComtactusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

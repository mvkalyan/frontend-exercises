import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ComtactusComponent } from './comtactus/comtactus.component';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
 // {path:"home",component:AppComponent},
  {path:"login",component:LoginComponent},
  {path:"register",component:RegistrationComponent,outlet:"rout1"},
  {path:"aboutus",component:AboutusComponent,outlet:"rout2"},
  {path:"contactus",component:ComtactusComponent},
  {path:"**",component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

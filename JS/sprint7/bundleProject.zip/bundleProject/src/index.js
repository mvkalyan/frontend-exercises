import './script1'
import './script2'
import { greet } from './script1'
// export default{
//     greet
// }
module.exorts={
    run:greet
}
console.log("This is script 1");
export function greet(){
    var name=prompt("Enter your name:");
    alert("Welcome "+name);
}
// greet();

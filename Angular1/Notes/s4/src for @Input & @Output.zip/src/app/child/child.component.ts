import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'child-tag',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {
  @Input()
  item:string=''; //I want the value for this item should come from parent -- app
 
}


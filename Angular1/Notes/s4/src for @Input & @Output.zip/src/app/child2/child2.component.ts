
import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
  styleUrls: ['./child2.component.css']
})
export class Child2Component {
  @Output()
  newItem=new EventEmitter<string>();

  sendData(str:string){
    console.log(str);
    this.newItem.emit(str);
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //template:'<h1>Hello</h1>',
  styleUrls: ['./app.component.css']
  //styles:['h1{color:red}']
})
export class AppComponent {
  title = 'my-first-app';

  name="Tabassum";
  flag=true;
  color="";
  linkAddress="http://www.google.com";

  greet()
  {
    alert("Hi");
  }

  changeColor(){
    if(this.flag==true){
      this.color="backgroundColor:blue";
      this.flag=false;
    }
    else{
      this.color="backgroundColor:Yellow";
      this.flag=true;
    }
  }
}

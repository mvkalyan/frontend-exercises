import { Directive, ElementRef, HostBinding, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appFocus]'
})
export class FocusDirective {

 @Input('appFocus')color:string="";

 constructor(private element:ElementRef){}

  // @HostBinding("style.backgroundColor")
  // bgColor="";

  @HostListener("focus") 
  whenClicked(){
    //this.bgColor="Yellow";
    //this.bgColor=this.color;
    this.element.nativeElement.style.backgroundColor=this.color;
  }

  @HostListener("blur") 
  whenDoubleClicked(){
    //this.bgColor="";
    this.element.nativeElement.style.backgroundColor="";
  }
 

}

import { FocusDirective } from './focus.directive';

describe('FocusDirective', () => {
  it('should create an instance', () => {
    const directive = new FocusDirective();
    expect(directive).toBeTruthy();
  });
});

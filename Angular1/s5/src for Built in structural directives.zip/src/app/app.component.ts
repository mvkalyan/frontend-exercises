import { Component } from '@angular/core';
import { Student } from './student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  condition:boolean=false;
  password:string="";
  newItem:string="";
  items:Array<string>=["Pen","Pencil","Book","Eraser"];

  s1=new Student(1,"Sayli");
  s2=new Student(2,"Minakshi");
  s3=new Student(3,"Jhanvi");
  myStudentArray:Array<Student>=[this.s1,this.s2,this.s3];



  validate(){
    if(this.password.length>5 && this.password.length<20){
      this.condition=false;
    }
    else{
      this.condition=true;
    }
  }

  add(){
    this.items.push(this.newItem);
  }

 
}

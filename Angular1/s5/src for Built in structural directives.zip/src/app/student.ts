export class Student {
    rollNo:number=0;
    name:string="";

    constructor(rollNo:number,name:string){
        this.name=name;
        this.rollNo=rollNo;
    }
}
